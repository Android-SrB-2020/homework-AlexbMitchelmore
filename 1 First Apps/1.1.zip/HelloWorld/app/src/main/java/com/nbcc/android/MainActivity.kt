package com.nbcc.android

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d("MainActivity", "Happy Birthday to Me");

        /**
        Log.d(TAG, msg: " ")

        findViewById<Button>(R.id.roll_Button).setOnClickListener{
            findViewById<ImageView>(R.id.dice1_image).setImageResource(rollDice())
            findViewById<ImageView>(R.id.dice2_image).setImageResource(rollDice())
            findViewById<ImageView>(R.id.dice3_image).setImageResource(rollDice())
        }
        **/
    }

    /**
    private fun rollDice() : Int{
        //return
        val resId = when ((1..6).random()){
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, msg: "In onResume")
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onRestart() {
        super.onRestart()
    }

    override fun onPause() {
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
    }
    **/


}
